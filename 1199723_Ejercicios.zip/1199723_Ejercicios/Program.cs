﻿
using _1199723_Ejercicios;

public class Program
{
    public static void Main(string[] args)
    {
        // Solicitamos datos
        Console.WriteLine("Ingrese el valor del radio: ");
        double radio = int.Parse(Console.ReadLine());

        // Instancia de la clase = Objeto
        Circulo objCirculo = new Circulo(radio);

        double Perimetro = 0.0;
        double Area = 0.0;
        double Volumen = 0.0;

        objCirculo.CalcularGeometria(ref Perimetro, ref Area, ref Volumen);

        Console.WriteLine("su perimetro es: " + Perimetro);
        Console.WriteLine("su area es: " + Area);
        Console.WriteLine("su volumen es: " + Volumen);

    }
}